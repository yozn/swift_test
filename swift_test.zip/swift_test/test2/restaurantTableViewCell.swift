//
//  restaurantTableViewCell.swift
//  test2
//
//  Created by RTC35 on 2017/10/13.
//  Copyright © 2017年 RTC35. All rights reserved.
//

import UIKit

class restaurantTableViewCell: UITableViewCell {
    @IBOutlet var nameLabel : UILabel!
    @IBOutlet var locationLabel : UILabel!
    @IBOutlet var typeLabel : UILabel!
    @IBOutlet var imagee:UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
